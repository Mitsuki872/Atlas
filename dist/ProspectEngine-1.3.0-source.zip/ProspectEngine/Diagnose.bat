@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" scripts\launcher.py diagnose
pause
